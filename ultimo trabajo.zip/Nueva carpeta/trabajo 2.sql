create database trabajo_4
use trabajo_4

CREATE TABLE Roles (
    ID INT PRIMARY KEY,
    Nombre VARCHAR(50)
);

CREATE TABLE Usuarios (
    ID INT PRIMARY KEY,
    Nombre VARCHAR(255),
    Contrase�a VARCHAR(255),
    RolID INT,
    FOREIGN KEY (RolID) REFERENCES Roles(ID)
);

CREATE TABLE Productos (
    ID INT PRIMARY KEY,
    Nombre VARCHAR(255),
    Precio DECIMAL(10, 2),
    Descripci�n TEXT,
    Tipo VARCHAR(50),
    Stock INT
);

CREATE TABLE Mesas (
    ID INT PRIMARY KEY,
    N�mero INT
);

CREATE TABLE Ordenes (
    ID INT PRIMARY KEY,
    IDCliente INT,
    IDMesa INT,
    Fecha DATETIME,
    Estado VARCHAR(50),
    FOREIGN KEY (IDCliente) REFERENCES Usuarios(ID),
    FOREIGN KEY (IDMesa) REFERENCES Mesas(ID)
);

CREATE TABLE Transacciones (
    ID INT PRIMARY KEY,
    Tipo VARCHAR(50),
    Monto DECIMAL(10, 2),
    Fecha DATETIME
);

CREATE TABLE Utilidades (
    ID INT PRIMARY KEY,
    Fecha DATE,
    UtilidadDiaria DECIMAL(10, 2),
    UtilidadMensual DECIMAL(10, 2)
);

select * from Roles
select * from Usuarios
select * from Productos
select * from Mesas
select * from Ordenes
select * from Transacciones
select * from Utilidades

----valores---
INSERT INTO Roles (ID, Nombre) VALUES
(1, 'Administrador'),
(2, 'Cliente'),
(3, 'Bodega'),
(4, 'Finanzas'),
(5, 'Cocina');

INSERT INTO Productos (ID, Nombre, Precio, Descripci�n, Tipo, Stock) VALUES
(1, 'Spaghetti Bolognese', 12.99, 'Classic Italian pasta with meat sauce', 'Plato Principal', 20),
(2, 'Caesar Salad', 8.99, 'Fresh romaine lettuce with Caesar dressing and croutons', 'Entrada', 15),
(3, 'Minestrone Soup', 6.99, 'Vegetable soup with pasta and beans', 'Entrada', 10),
(4, 'Tiramisu', 5.99, 'Italian coffee-flavored dessert', 'Postre', 25),
(5, 'Soda', 2.49, 'Carbonated beverage', 'Bebida', 50);


INSERT INTO Usuarios (ID, Nombre, Contrase�a, RolID) VALUES
(1, 'JoseAdmin', 'contrase�a123', 1),
(2, 'Cliente1', 'cliente123', 2),
(3, 'Bodeguero1', 'bodega123', 3),
(4, 'Finanzas1', 'finanzas123', 4),
(5, 'Cocinero1', 'cocina123', 5);

INSERT INTO Mesas (ID, N�mero) VALUES
(1, 101),
(2, 102),
(3, 103);

INSERT INTO Ordenes (ID, IDCliente, IDMesa, Fecha, Estado) VALUES
(1, 2, 1, '2023-01-15 12:30:00', 'En proceso'),
(2, 2, 2, '2023-01-15 13:00:00', 'Lista para servir'),
(3, 3, 3, '2023-01-15 13:30:00', 'En proceso');

INSERT INTO Transacciones (ID, Tipo, Monto, Fecha) VALUES
(1, 'Ingreso', 150.00, '2023-01-15 12:30:00'),
(2, 'Egreso', 30.00, '2023-01-15 13:15:00'),
(3, 'Ingreso', 100.00, '2023-01-15 14:00:00');

INSERT INTO Utilidades (ID, Fecha, UtilidadDiaria, UtilidadMensual) VALUES
(1, '2023-01-15', 120.00, 70.00);
