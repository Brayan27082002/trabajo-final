create database problema_3
use problema_3


CREATE TABLE Usuarios (
    IDUsuario INT PRIMARY KEY,
    Nombre VARCHAR(50),
    Apellido VARCHAR(50),
    EstadoCivil VARCHAR(20),
    Comuna VARCHAR(50)
);


CREATE TABLE Empresas (
    IDEmpresa INT PRIMARY KEY,
    NombreEmpresa VARCHAR(50)
);


CREATE TABLE Usuarios_Empresas (
    IDUsuario INT,
    IDEmpresa INT,
    PRIMARY KEY (IDUsuario, IDEmpresa),
    FOREIGN KEY (IDUsuario) REFERENCES Usuarios(IDUsuario),
    FOREIGN KEY (IDEmpresa) REFERENCES Empresas(IDEmpresa)
);

CREATE TABLE Asistencias (
    IDAsistencia INT PRIMARY KEY,
    IDUsuario INT,
    IDEmpresa INT,
    FechaAsistencia DATE,
    FOREIGN KEY (IDUsuario) REFERENCES Usuarios(IDUsuario),
    FOREIGN KEY (IDEmpresa) REFERENCES Empresas(IDEmpresa)
);

select * from Usuarios
select * from Usuarios_Empresas
select * from Empresas
select * from Asistencias

-- Insertar datos en la tabla de Usuarios
INSERT INTO Usuarios (IDUsuario, Nombre, Apellido, EstadoCivil, Comuna)
VALUES
    (1, 'John', 'Doe', 'Casado', 'Santiago'),
    (2, 'Jane', 'Smith', 'Soltero', 'Providencia'),
    (3, 'Michael', 'Johnson', 'Divorciado', 'Las Condes');

-- Insertar datos en la tabla de Empresas
INSERT INTO Empresas (IDEmpresa, NombreEmpresa)
VALUES
    (1, 'Austral Corp'),
    (2, 'American Tur'),
    (3, 'Astral Trip');

-- Insertar datos en la tabla de Usuarios_Empresas
INSERT INTO Usuarios_Empresas (IDUsuario, IDEmpresa)
VALUES
    (1, 1), -- John Doe trabaja en Austral Corp
    (1, 2), -- John Doe tambi�n trabaja en American Tur
    (2, 1), -- Jane Smith trabaja en Austral Corp
    (3, 3); -- Michael Johnson trabaja en Astral Trip

-- Insertar datos en la tabla de Asistencias
INSERT INTO Asistencias (IDAsistencia, IDUsuario, IDEmpresa, FechaAsistencia)
VALUES
    (1, 1, 1, '2023-12-01'),
    (2, 1, 2, '2023-12-02'),
    (3, 2, 1, '2023-12-01'),
    (4, 3, 3, '2023-12-03');


--------
SELECT e.NombreEmpresa, u.EstadoCivil, COUNT(*) as Cantidad
FROM Empresas e
JOIN Usuarios_Empresas ue ON e.IDEmpresa = ue.IDEmpresa
JOIN Usuarios u ON ue.IDUsuario = u.IDUsuario
GROUP BY e.NombreEmpresa, u.EstadoCivil;
--------
SELECT e.NombreEmpresa, u.Comuna, COUNT(*) as Cantidad
FROM Empresas e
JOIN Usuarios_Empresas ue ON e.IDEmpresa = ue.IDEmpresa
JOIN Usuarios u ON ue.IDUsuario = u.IDUsuario
GROUP BY e.NombreEmpresa, u.Comuna;
--------
SELECT e.NombreEmpresa, COUNT(*) as TotalEmpleados
FROM Empresas e
JOIN Usuarios_Empresas ue ON e.IDEmpresa = ue.IDEmpresa
GROUP BY e.NombreEmpresa;
---------
SELECT u.Nombre, u.Apellido, a.FechaAsistencia
FROM Usuarios u
JOIN Asistencias a ON u.IDUsuario = a.IDUsuario;
---------
SELECT e.NombreEmpresa, a.FechaAsistencia
FROM Empresas e
JOIN Asistencias a ON e.IDEmpresa = a.IDEmpresa;

